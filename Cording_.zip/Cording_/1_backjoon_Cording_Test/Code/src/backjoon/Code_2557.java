package backjoon;

public class Code_2557 {

	public static void main(String[] args) {
		code();
	}
	
	// "Hello World" 출력하기	
		public static void code() {
			System.out.println("Hello World!");
		}
}
