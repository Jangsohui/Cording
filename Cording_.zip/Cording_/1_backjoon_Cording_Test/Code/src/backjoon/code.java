package backjoon;

import java.util.Scanner;

public class code {
	static Scanner scan = null;

	public static void main(String[] args) {
		scan = new Scanner(System.in);
		code_1();
		code_2();
		code_3();
		code_4();
		code_5();
	}

// "Hello World" 출력하기	
	public static void code_1() {
		System.out.println("Hello World!");
	}

// 	두 정수를 입력 받은 후 더한 값을 출력하시오
	public static void code_2() {
		System.out.println("덧셈할 정수 두개를 입력하세요.");

		System.out.print("A: ");
		int iNum1 = scan.nextInt();

		System.out.print("B: ");
		int iNum2 = scan.nextInt();

		int temp = iNum1 + iNum2;
		System.out.println("값: " + temp);
	}

//  개모양 출력하기
	public static void code_3() {
		System.out.println( "|\\_/|");
		System.out.println("|q p|   /}");
		System.out.println("( 0 )\"\"\"\\");
		System.out.println("|\"^\"`    |");
		System.out.println("||_/=\\\\__|");
	}

// 	두 정수를 입력 받은 후 뺄셈한 값을 출력하시오
	public static void code_4() {
		System.out.println("뺄셈할 정수 두개를 입력하세요.");

		System.out.print("A: ");
		int iNum1 = scan.nextInt();

		System.out.print("B: ");
		int iNum2 = scan.nextInt();

		int temp = iNum1 - iNum2;
		System.out.println("값: " + temp);
	}

// 	입력 받은 대로 출력하기
// 최대 100줄, 각 줄은 100글자를 넘기지 않으며 빈줄은 주어지지 않음, 각줄은 공백으로 시작하지 않고 공백으로 끝나지 않는다.
	public static void code_5() {
		while (scan.hasNextLine()) {
	        while(scan.hasNextLine()) {
	            String input = scan.nextLine();
	            System.out.println(input);
	        }
	        scan.close();
	    }
	}

}
