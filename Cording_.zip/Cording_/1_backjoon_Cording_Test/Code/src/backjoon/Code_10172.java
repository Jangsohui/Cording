package backjoon;

public class Code_10172 {

	public static void main(String[] args) {
		code();
	}
	
//  개모양 출력하기
	public static void code() {
		System.out.println( "|\\_/|");
		System.out.println("|q p|   /}");
		System.out.println("( 0 )\"\"\"\\");
		System.out.println("|\"^\"`    |");
		System.out.println("||_/=\\\\__|");
	}
}
